define([], () => {
  'use strict';

  class AppModule {



    
  }

  AppModule.prototype.logToConsole = function (msg1, obj1) {

    console.log(msg1, obj1);

    
  };

    AppModule.prototype.newArray = function (obj1) {

    let obj = {
      "firstName": "John",
      "lastName": "Kolden",
      "emailAddress": "john@g.com",
      "qualification": "CPA"
    };

    obj1.push(obj);

    console.log(obj1);

    return obj1;
    
  };



   AppModule.prototype.getArrayLength = function (array) {
    return array.length;
  };
  
  return AppModule;
});
