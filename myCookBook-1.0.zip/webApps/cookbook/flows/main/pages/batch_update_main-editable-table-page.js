define([], () => {
  'use strict';

  class PageModule {
  }
  
  PageModule.generateBatch = function(url, payload, operation, id) {
    return {
      id: id ? id : "part1",
      path: url,
      operation: operation,
      payload: payload ? payload : {}
    };
  };


  PageModule.prototype.buildBatchPayload = function(empArray, idArray) {
    var payloads = [];
    var record;
    idArray.forEach(user => {     
      record = empArray.find(e => e.id === user.id);
      payloads.push(PageModule.generateBatch("/Employee/" +
          user.id, record, 'update',user.id));

    });

    return {
      parts: payloads
    };
  };

  return PageModule;
});
